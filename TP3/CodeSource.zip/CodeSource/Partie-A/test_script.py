def crash_if_too_long(s):
    if len(s) > 9: # 9 characters
        raise ValueError


